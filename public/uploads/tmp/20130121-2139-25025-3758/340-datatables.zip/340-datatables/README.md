# RailsCasts Episode #340: DataTables

http://railscasts.com/episodes/341-datatables

Requires Ruby 1.9.2 or higher.
